﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeAssignment.Models;
using System.Text;
using System.IO;

namespace HomeAssignment.Controllers
{
    public class InquiriesController : Controller
    {
        private readonly CustomerSupportContext _context;

        public InquiriesController(CustomerSupportContext context)
        {
            _context = context;
        }

        // GET: Inquiries
        public async Task<IActionResult> Index()
        {
            return View(await _context.Inquiries.ToListAsync());
        }

        // GET: Inquiries/Details/5
      
        // GET: Inquiries/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Inquiries/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("InquiryId,CustomerEmail,CustomerPhone,CustomerNumber,InqiryType,InquiryDescription,TermsConditions,InquiryStatus,CreateDate")] Inquiries inquiries)
        {
            if (ModelState.IsValid)
            {
                _context.Add(inquiries);
                await _context.SaveChangesAsync();
                //Save to file & download
               // SaveData("Email : " + inquiries.CustomerEmail + " , " + "Customer Phone : " + inquiries.CustomerPhone + " , " + "Customer Number : " + inquiries.CustomerNumber + " , " + "Inquiry Type : " + inquiries.InqiryType + " , " + "Description : " + inquiries.InquiryDescription+" , "+ inquiries.TermsConditions+" , "+ inquiries.InquiryStatus+" , "+ inquiries.CreateDate);
                return RedirectToAction(nameof(message));
            }
            return View(inquiries);
        }

        public FileStreamResult SaveData(string text)
        {
            var string_with_your_data = text;
            var byteArray = Encoding.Default.GetBytes(string_with_your_data);
            var stream = new MemoryStream(byteArray);
            return File(stream, "text/plain", String.Format("formdata.txt", text));
        }
        public IActionResult message()
        {
            return View();
        }

        private bool InquiriesExists(int id)
        {
            return _context.Inquiries.Any(e => e.InquiryId == id);
        }
    }
}
