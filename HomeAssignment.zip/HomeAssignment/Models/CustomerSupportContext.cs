﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace HomeAssignment.Models
{
    public partial class CustomerSupportContext : DbContext
    {
        public CustomerSupportContext()
        {
        }

        public CustomerSupportContext(DbContextOptions<CustomerSupportContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Inquiries> Inquiries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Inquiries>(entity =>
            {
                entity.HasKey(e => e.InquiryId)
                    .HasName("PK__inquirie__9A3E8C6F1BF88EA0");

                entity.ToTable("inquiries");

                entity.Property(e => e.InquiryId).HasColumnName("inquiryId");

                entity.Property(e => e.CreateDate)
                    .HasColumnName("createDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerEmail)
                    .IsRequired()
                    .HasColumnName("customerEmail")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CustomerPhone)
                    .IsRequired()
                    .HasColumnName("customerPhone")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InqiryType)
                    .IsRequired()
                    .HasColumnName("inqiryType")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InquiryDescription)
                    .IsRequired()
                    .HasColumnName("inquiryDescription")
                    .HasColumnType("text");

                entity.Property(e => e.InquiryStatus)
                    .IsRequired()
                    .HasColumnName("inquiryStatus")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Received')");

                entity.Property(e => e.TermsConditions)
                    .IsRequired()
                    .HasColumnName("termsConditions")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
