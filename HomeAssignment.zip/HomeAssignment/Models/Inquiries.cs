﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HomeAssignment.Models
{
    public partial class Inquiries
    {
        
        public int InquiryId { get; set; }

        [Required]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string CustomerEmail { get; set; }
       

        [Required]
        [Display(Name = "Phone No.")]
        [DataType(DataType.PhoneNumber)]
        public string CustomerPhone { get; set; }
       

        [Display(Name = "Customer Number")]
        public string CustomerNumber { get; set; }
      
        [Required]
        [Display(Name = "Inquiry Type")]
        public string InqiryType { get; set; }

        [Required]
        [Display(Name = "Description")]
        public string InquiryDescription { get; set; }

        [Display(Name = "I agree to the Terms and Conditions")]
        public bool TermsConditions { get; set; }
       
        public string InquiryStatus { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
